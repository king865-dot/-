// UrlEncoderFilter.java
package edu.wtbu.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class UrlEncoderFilter implements Filter {
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("URL编码过滤器初始化完成");
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String requestURI = httpRequest.getRequestURI();
        String queryString = httpRequest.getQueryString();
        
        // 记录请求信息用于调试
        System.out.println("请求URI: " + requestURI);
        if (queryString != null) {
            System.out.println("查询参数: " + queryString);
        }
        
        chain.doFilter(new UrlEncodedRequestWrapper(httpRequest), response);
    }
    
    @Override
    public void destroy() {
        System.out.println("URL编码过滤器销毁");
    }
    
    private static class UrlEncodedRequestWrapper extends HttpServletRequestWrapper {
        public UrlEncodedRequestWrapper(HttpServletRequest request) {
            super(request);
        }
        
        @Override
        public String getRequestURI() {
            String uri = super.getRequestURI();
            try {
                return URLDecoder.decode(uri, StandardCharsets.UTF_8.name());
            } catch (Exception e) {
                System.err.println("URL解码失败: " + uri);
                return uri;
            }
        }
        
        @Override
        public String getQueryString() {
            String query = super.getQueryString();
            if (query != null) {
                try {
                    return URLDecoder.decode(query, StandardCharsets.UTF_8.name());
                } catch (Exception e) {
                    System.err.println("查询字符串解码失败: " + query);
                }
            }
            return query;
        }
    }
}