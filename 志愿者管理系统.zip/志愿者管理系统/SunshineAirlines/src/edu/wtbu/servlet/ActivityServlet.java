// ActivityServlet.java
package edu.wtbu.servlet;

import java.io.IOException;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import edu.wtbu.pojo.Result;
import edu.wtbu.service.ActivityService;

@WebServlet("/activity")
public class ActivityServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
    	request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        Result result = null;
        
        try {
            switch(action) {
                case "list":
                    result = handleList(request);
                    break;
                case "publishedList": // 新增：学生查看已发布活动
                    result = handlePublishedList(request);
                    break;
                case "add":
                    result = handleAdd(request);
                    break;
                case "update":
                    result = handleUpdate(request);
                    break;
                case "detail":
                    result = handleDetail(request);
                    break;
                default:
                    result = new Result("fail", null, "无效操作");
            }
        } catch (Exception e) {
            result = new Result("error", null, "系统异常");
        }
        
        response.getWriter().append(JSON.toJSONString(result));
    }

    private Result handleList(HttpServletRequest request) {
        String title = request.getParameter("title") != null ? request.getParameter("title") : "";
        String status = request.getParameter("status") != null ? request.getParameter("status") : "";
        int startPage = parseInt(request.getParameter("startPage"), 1);
        int pageSize = parseInt(request.getParameter("pageSize"), 10);
        return ActivityService.activityList(title, status, startPage, pageSize);
    }

    private Result handlePublishedList(HttpServletRequest request) {
        int startPage = parseInt(request.getParameter("startPage"), 1);
        int pageSize = parseInt(request.getParameter("pageSize"), 10);
        return ActivityService.publishedActivityList(startPage, pageSize);
    }

    private Result handleAdd(HttpServletRequest request) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("title", request.getParameter("title"));
        map.put("description", request.getParameter("description"));
        System.out.println(request.getParameter("description"));
        map.put("organizer", request.getParameter("organizer"));
        map.put("startTime", request.getParameter("startTime"));
        map.put("endTime", request.getParameter("endTime"));
        map.put("location", request.getParameter("location"));
        map.put("recruitCount", parseInt(request.getParameter("recruitCount"), 0));
        map.put("defaultHours", parseFloat(request.getParameter("defaultHours"), 0.0f));
        map.put("status", "published");
        return ActivityService.addActivity(map);
    }

    private Result handleUpdate(HttpServletRequest request) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("activityId", request.getParameter("activityId"));
        map.put("title", request.getParameter("title"));
        map.put("description", request.getParameter("description"));
        map.put("organizer", request.getParameter("organizer"));
        map.put("startTime", request.getParameter("startTime"));
        map.put("endTime", request.getParameter("endTime"));
        map.put("location", request.getParameter("location"));
        map.put("recruitCount", parseInt(request.getParameter("recruitCount"), 0));
        map.put("defaultHours", parseFloat(request.getParameter("defaultHours"), 0.0f));
        map.put("status", request.getParameter("status"));
        return ActivityService.updateActivity(map);
    }

    private Result handleDetail(HttpServletRequest request) {
        String activityId = request.getParameter("activityId");
        return ActivityService.getActivityDetail(activityId);
    }

    private int parseInt(String value, int defaultValue) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    private float parseFloat(String value, float defaultValue) {
        try {
            return Float.parseFloat(value);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPost(request, response);
    }
}