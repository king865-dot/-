// StatisticsServlet.java
package edu.wtbu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import edu.wtbu.pojo.Result;
import edu.wtbu.service.StatisticsService;

@WebServlet("/statistics")
public class StatisticsServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        Result result = null;
        
        try {
            switch(action) {
                case "studentRecord":
                    result = handleStudentRecord(request);
                    break;
                case "classStats":
                    result = handleClassStats(request);
                    break;
                case "collegeStats":
                    result = handleCollegeStats(request);
                    break;
                case "recordHours": // 新增：记录服务时长
                    result = handleRecordHours(request);
                    break;
                default:
                    result = new Result("fail", null, "无效操作");
            }
        } catch (Exception e) {
            e.printStackTrace(); // 添加错误日志
            result = new Result("error", null, "系统异常");
        }
        
        response.getWriter().append(JSON.toJSONString(result));
    }

    private Result handleStudentRecord(HttpServletRequest request) {
        String studentId = request.getParameter("studentId");
        if (studentId == null || studentId.isEmpty()) {
            return new Result("fail", null, "学号不能为空");
        }
        return StatisticsService.getStudentServiceRecord(studentId);
    }

    private Result handleClassStats(HttpServletRequest request) {
        return StatisticsService.getClassStatistics();
    }

    private Result handleCollegeStats(HttpServletRequest request) {
        return StatisticsService.getCollegeStatistics();
    }

    private Result handleRecordHours(HttpServletRequest request) {
        String studentId = request.getParameter("studentId");
        String activityId = request.getParameter("activityId");
        float hours = parseFloat(request.getParameter("hours"), 0.0f);
        
        if (studentId == null || studentId.isEmpty()) {
            return new Result("fail", null, "学号不能为空");
        }
        if (activityId == null || activityId.isEmpty()) {
            return new Result("fail", null, "活动ID不能为空");
        }
        if (hours <= 0) {
            return new Result("fail", null, "服务时长必须大于0");
        }
        
        return StatisticsService.recordServiceHours(studentId, activityId, hours);
    }

    private float parseFloat(String value, float defaultValue) {
        try {
            return Float.parseFloat(value);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPost(request, response);
    }
}