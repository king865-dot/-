// SignupServlet.java
package edu.wtbu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import edu.wtbu.pojo.Result;
import edu.wtbu.service.SignupService;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        Result result = null;
        
        try {
            switch(action) {
                case "signup":
                    result = handleSignup(request);
                    break;
                case "list":
                    result = handleList(request);
                    break;
                case "approve":
                    result = handleApprove(request);
                    break;
                case "mySignups":
                    result = handleMySignups(request);
                    break;
                default:
                    result = new Result("fail", null, "无效操作");
            }
        } catch (Exception e) {
            result = new Result("error", null, "系统异常");
        }
        
        response.getWriter().append(JSON.toJSONString(result));
    }

    private Result handleSignup(HttpServletRequest request) {
        String activityId = request.getParameter("activityId");
        String studentId = request.getParameter("studentId"); // 从session获取
        return SignupService.signupActivity(activityId, studentId);
    }

    private Result handleList(HttpServletRequest request) {
        String activityId = request.getParameter("activityId");
        String status = request.getParameter("status") != null ? request.getParameter("status") : "";
        int startPage = parseInt(request.getParameter("startPage"), 1);
        int pageSize = parseInt(request.getParameter("pageSize"), 10);
        return SignupService.getActivitySignups(activityId, status, startPage, pageSize);
    }

    private Result handleApprove(HttpServletRequest request) {
        String signupId = request.getParameter("signupId");
        String status = request.getParameter("status");
        return SignupService.approveSignup(signupId, status);
    }

    private Result handleMySignups(HttpServletRequest request) {
        String studentId = request.getParameter("studentId"); // 从session获取
        int startPage = parseInt(request.getParameter("startPage"), 1);
        int pageSize = parseInt(request.getParameter("pageSize"), 10);
        return SignupService.getStudentSignups(studentId, startPage, pageSize);
    }

    private int parseInt(String value, int defaultValue) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPost(request, response);
    }
}