// StudentServlet.java
package edu.wtbu.servlet;

import java.io.IOException;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSON;
import edu.wtbu.pojo.Result;
import edu.wtbu.service.StudentService;

@WebServlet("/student")
public class StudentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // 设置请求和响应的字符编码为UTF-8
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        
        String action = request.getParameter("action");
        Result result = null;
        
        try {
            switch(action) {
                case "login":
                    result = handleLogin(request);
                    break;
                case "list":
                    result = handleList(request);
                    break;
                case "add":
                    result = handleAdd(request);
                    break;
                case "update":
                    result = handleUpdate(request);
                    break;
                case "delete":
                    result = handleDelete(request);
                    break;
                case "detail":
                    result = handleDetail(request);
                    break;
                case "classes":
                    result = handleClasses(request);
                    break;
                default:
                    result = new Result("fail", null, "无效操作");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result = new Result("error", null, "系统异常: " + e.getMessage());
        }
        
        response.getWriter().append(JSON.toJSONString(result));
    }

    private Result handleLogin(HttpServletRequest request) {
        String studentId = request.getParameter("studentId");
        String password = request.getParameter("password");
        Result result = StudentService.login(studentId, password);
        
        // 登录成功，将用户信息存入session
        if("success".equals(result.getFlag())) {
            HttpSession session = request.getSession();
            session.setAttribute("student", result.getData());
        }
        
        return result;
    }

    private Result handleList(HttpServletRequest request) {
        String keyword = request.getParameter("keyword") != null ? request.getParameter("keyword") : "";
        int startPage = parseInt(request.getParameter("startPage"), 1);
        int pageSize = parseInt(request.getParameter("pageSize"), 10);
        return StudentService.studentList(keyword, startPage, pageSize);
    }

    private Result handleAdd(HttpServletRequest request) {
        System.out.println("=== 接收到添加学生请求 ===");
        java.util.Enumeration<String> paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String paramName = paramNames.nextElement();
            String paramValue = request.getParameter(paramName);
            System.out.println("参数: " + paramName + " = " + paramValue);
        }
        
        HashMap<String, Object> map = new HashMap<>();
        map.put("name", request.getParameter("name"));
        map.put("password", request.getParameter("password"));
        map.put("role", request.getParameter("role"));
        map.put("classId", parseInt(request.getParameter("classId"), 0));
        map.put("phone", request.getParameter("phone"));
        map.put("email", request.getParameter("email"));
        
        System.out.println("处理后的参数: " + map);
        return StudentService.addStudent(map);
    }

    private Result handleUpdate(HttpServletRequest request) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("studentId", request.getParameter("studentId"));
        map.put("name", request.getParameter("name"));
        map.put("role", request.getParameter("role"));
        map.put("classId", parseInt(request.getParameter("classId"), 0));
        map.put("phone", request.getParameter("phone"));
        map.put("email", request.getParameter("email"));
        return StudentService.updateStudent(map);
    }

    private Result handleDelete(HttpServletRequest request) {
        String studentId = request.getParameter("studentId");
        return StudentService.deleteStudent(studentId);
    }

    private Result handleDetail(HttpServletRequest request) {
        String studentId = request.getParameter("studentId");
        return StudentService.getStudentDetail(studentId);
    }
    
    private Result handleClasses(HttpServletRequest request) {
        return StudentService.getClassList();
    }

    private int parseInt(String value, int defaultValue) {
        if (value == null || value.trim().isEmpty()) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPost(request, response);
    }
}