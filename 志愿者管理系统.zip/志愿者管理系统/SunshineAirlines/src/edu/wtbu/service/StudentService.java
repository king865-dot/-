// StudentService.java
package edu.wtbu.service;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.dao.StudentDao;
import edu.wtbu.pojo.Page;
import edu.wtbu.pojo.Result;
import edu.wtbu.util.IDGenerator;

public class StudentService {
    
    // 学生登录
    public static Result login(String studentId, String password) {
        Result result = new Result("fail", null, "登录失败");
        
        if(studentId == null || studentId.isEmpty()) {
            result.setData("学号不能为空");
            return result;
        }
        
        if(password == null || password.isEmpty()) {
            result.setData("密码不能为空");
            return result;
        }
        
        HashMap<String, Object> student = StudentDao.login(studentId, password);
        if(student != null) {
            result.setFlag("success");
            result.setData(student);
        } else {
            result.setData("学号或密码错误");
        }
        return result;
    }
    
    // 学生列表查询（带分页）
    public static Result studentList(String keyword, int startPage, int pageSize) {
        List<HashMap<String, Object>> list = StudentDao.findStudentListByPage(keyword, startPage, pageSize);
        int total = StudentDao.findStudentCount(keyword);
        Page page = new Page(total, startPage, pageSize);
        return new Result("success", page, list);
    }
    
    // 添加学生
    public static Result addStudent(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "添加失败");
        
        System.out.println("=== Service层开始处理添加学生 ===");
        System.out.println("Service接收到的参数: " + map);
        
        // 检查必要参数是否存在
        if (map == null) {
            result.setData("参数不能为空");
            return result;
        }
        
        // 验证姓名
        if (map.get("name") == null || map.get("name").toString().trim().isEmpty()) {
            result.setData("姓名不能为空");
            return result;
        }
        
        // 验证角色
        if (map.get("role") == null) {
            result.setData("角色不能为空");
            return result;
        }
        
        String role = map.get("role").toString();
        if (!"student".equals(role) && !"admin".equals(role)) {
            result.setData("角色必须为student或admin");
            return result;
        }
        
        // 验证班级ID
        if (map.get("classId") == null) {
            result.setData("班级不能为空");
            return result;
        }
        
        int classId;
        try {
            classId = Integer.parseInt(map.get("classId").toString());
            if (classId <= 0) {
                result.setData("请选择有效的班级");
                return result;
            }
        } catch (NumberFormatException e) {
            System.err.println("班级ID转换异常: " + map.get("classId"));
            result.setData("班级ID格式错误");
            return result;
        }
        
        // 生成学号
        String studentId;
        int maxAttempts = 10;
        int attempts = 0;
        
        do {
            studentId = IDGenerator.generateStudentId();
            attempts++;
            if (attempts > maxAttempts) {
                result.setData("生成学号失败，请稍后重试");
                return result;
            }
        } while (StudentDao.isStudentIdExists(studentId));
        
        map.put("studentId", studentId);
        System.out.println("生成的学号: " + studentId);
        
        // 设置默认密码
        if (map.get("password") == null || map.get("password").toString().trim().isEmpty()) {
            map.put("password", "123456");
        }
        
        // 调用DAO
        try {
            System.out.println("准备调用DAO添加学生...");
            int addResult = StudentDao.addStudent(map);
            System.out.println("DAO返回结果: " + addResult);
            
            if (addResult > 0) {
                result.setFlag("success");
                result.setData("添加成功！学号：" + studentId + "，密码：" + map.get("password"));
            } else if (addResult == 0) {
                result.setData("添加失败，可能数据已存在");
            } else {
                result.setData("数据库操作失败");
            }
        } catch (Exception e) {
            System.err.println("添加学生时发生异常: " + e.getMessage());
            e.printStackTrace();
            result.setData("系统错误: " + e.getMessage());
        }
        
        System.out.println("=== Service层处理完成 ===");
        return result;
    }
    
    // 更新学生信息
    public static Result updateStudent(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "更新失败");
        String studentId = map.get("studentId").toString();
        
        // 校验学生是否存在
        if(StudentDao.findByStudentId(studentId) == null) {
            result.setData("学生不存在");
            return result;
        }
        
        if(StudentDao.updateStudent(map) > 0) {
            result.setFlag("success");
            result.setData("更新成功");
        }
        return result;
    }
    
    // 删除学生
    public static Result deleteStudent(String studentId) {
        Result result = new Result("fail", null, "删除失败");
        if(StudentDao.deleteStudent(studentId) > 0) {
            result.setFlag("success");
            result.setData("删除成功");
        }
        return result;
    }
    
    // 获取学生详情
    public static Result getStudentDetail(String studentId) {
        Result result = new Result("fail", null, "学生不存在");
        HashMap<String, Object> student = StudentDao.findByStudentId(studentId);
        if(student != null) {
            result.setFlag("success");
            result.setData(student);
        }
        return result;
    }
    
    // 获取班级列表
    public static Result getClassList() {
        List<HashMap<String, Object>> classes = StudentDao.findAllClasses();
        return new Result("success", null, classes);
    }
}