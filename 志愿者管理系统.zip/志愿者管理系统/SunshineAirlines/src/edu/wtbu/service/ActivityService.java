// ActivityService.java
package edu.wtbu.service;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.dao.ActivityDao;
import edu.wtbu.pojo.Page;
import edu.wtbu.pojo.Result;

public class ActivityService {
    
    // 活动列表查询
    public static Result activityList(String title, String status, int startPage, int pageSize) {
        try {
            List<HashMap<String, Object>> list = ActivityDao.findActivityListByPage(title, status, startPage, pageSize);
            int total = ActivityDao.findActivityCount(title, status);
            Page page = new Page(total, startPage, pageSize);
            
            // 调试信息
            System.out.println("查询到活动数量: " + (list != null ? list.size() : 0));
            if (list != null) {
                for (HashMap<String, Object> activity : list) {
                    System.out.println("活动标题: " + activity.get("title"));
                }
            }
            
            return new Result("success", page, list);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result("error", null, "查询活动列表时发生错误");
        }
    }
    
    // 已发布活动列表（学生用）
    public static Result publishedActivityList(int startPage, int pageSize) {
        try {
            List<HashMap<String, Object>> list = ActivityDao.findPublishedActivities(startPage, pageSize);
            int total = ActivityDao.findPublishedActivityCount();
            Page page = new Page(total, startPage, pageSize);
            
            System.out.println("查询到已发布活动数量: " + (list != null ? list.size() : 0));
            
            return new Result("success", page, list);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result("error", null, "查询已发布活动列表时发生错误");
        }
    }
    
    // 发布活动
    public static Result addActivity(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "发布失败");
        
        // 参数校验
        if(map.get("title") == null || map.get("title").toString().trim().isEmpty()) {
            result.setData("活动标题不能为空");
            return result;
        }
        
        int ret = ActivityDao.addActivity(map);
        if(ret > 0) {
            result.setFlag("success");
            result.setData("发布成功");
        } else if (ret == -1) {
            result.setData("活动标题不能为空");
        }
        return result;
    }
    
    // 更新活动
    public static Result updateActivity(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "更新失败");
        String activityId = map.get("activityId").toString();
        
        if(ActivityDao.findByActivityId(activityId) == null) {
            result.setData("活动不存在");
            return result;
        }
        
        int ret = ActivityDao.updateActivity(map);
        if(ret > 0) {
            result.setFlag("success");
            result.setData("更新成功");
        } else if (ret == -1) {
            result.setData("活动标题不能为空");
        }
        return result;
    }
    
    // 获取活动详情
    public static Result getActivityDetail(String activityId) {
        Result result = new Result("fail", null, "活动不存在");
        HashMap<String, Object> activity = ActivityDao.findByActivityId(activityId);
        if(activity != null) {
            result.setFlag("success");
            result.setData(activity);
        }
        return result;
    }
}