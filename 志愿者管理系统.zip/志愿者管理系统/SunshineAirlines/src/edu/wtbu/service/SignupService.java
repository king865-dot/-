// SignupService.java
package edu.wtbu.service;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.dao.ActivitySignupDao;
import edu.wtbu.pojo.Page;
import edu.wtbu.pojo.Result;

public class SignupService {
    
    // 学生报名活动
    public static Result signupActivity(String activityId, String studentId) {
        Result result = new Result("fail", null, "报名失败");
        int ret = ActivitySignupDao.signupActivity(activityId, studentId);
        if(ret > 0) {
            result.setFlag("success");
            result.setData("报名成功，等待审核");
        } else if(ret == -1) {
            result.setData("您已报名该活动");
        } else if(ret == -2) {
            result.setData("活动不存在或未发布");
        }
        return result;
    }
    
    // 查询活动报名列表
    public static Result getActivitySignups(String activityId, String status, int startPage, int pageSize) {
        List<HashMap<String, Object>> list = ActivitySignupDao.findSignupListByActivity(activityId, status, startPage, pageSize);
        int total = ActivitySignupDao.findSignupCountByActivity(activityId, status);
        Page page = new Page(total, startPage, pageSize);
        return new Result("success", page, list);
    }
    
    // 审核报名
    public static Result approveSignup(String signupId, String status) {
        Result result = new Result("fail", null, "审核失败");
        
        // 获取报名信息
        HashMap<String, Object> signup = ActivitySignupDao.findSignupById(signupId);
        if(signup == null) {
            result.setData("报名记录不存在");
            return result;
        }
        
        if(ActivitySignupDao.updateSignupStatus(signupId, status) > 0) {
            result.setFlag("success");
            result.setData("审核成功");
            
            // 如果审核通过，自动记录服务时长
            if("approved".equals(status)) {
                String studentId = signup.get("student_id").toString();
                String activityId = signup.get("activity_id").toString();
                float defaultHours = Float.parseFloat(signup.get("default_hours").toString());
                
                // 记录服务时长
                edu.wtbu.dao.ServiceHoursDao.recordServiceHours(studentId, activityId, defaultHours);
            }
        }
        return result;
    }
    
    // 查询学生报名记录
    public static Result getStudentSignups(String studentId, int startPage, int pageSize) {
        List<HashMap<String, Object>> list = ActivitySignupDao.findStudentSignups(studentId, startPage, pageSize);
        int total = ActivitySignupDao.findStudentSignupCount(studentId);
        Page page = new Page(total, startPage, pageSize);
        return new Result("success", page, list);
    }
}