// StatisticsService.java
package edu.wtbu.service;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.dao.ServiceHoursDao;
import edu.wtbu.pojo.Result;

public class StatisticsService {
    
    // 获取个人服务档案
    public static Result getStudentServiceRecord(String studentId) {
        Result result = new Result("success", null, null);
        List<HashMap<String, Object>> records = ServiceHoursDao.findStudentServiceRecord(studentId);
        float totalHours = ServiceHoursDao.getStudentTotalHours(studentId);
        
        HashMap<String, Object> data = new HashMap<>();
        data.put("records", records);
        data.put("totalHours", totalHours);
        data.put("activityCount", records.size());
        
        result.setData(data);
        return result;
    }
    
    // 记录服务时长
    public static Result recordServiceHours(String studentId, String activityId, float hours) {
        Result result = new Result("fail", null, "记录失败");
        if(ServiceHoursDao.recordServiceHours(studentId, activityId, hours) > 0) {
            result.setFlag("success");
            result.setData("时长记录成功");
        }
        return result;
    }
    
    // 班级统计
    public static Result getClassStatistics() {
        List<HashMap<String, Object>> stats = ServiceHoursDao.getClassHoursStats();
        return new Result("success", null, stats);
    }
    
    // 学院统计
    public static Result getCollegeStatistics() {
        List<HashMap<String, Object>> stats = ServiceHoursDao.getCollegeHoursStats();
        return new Result("success", null, stats);
    }
}