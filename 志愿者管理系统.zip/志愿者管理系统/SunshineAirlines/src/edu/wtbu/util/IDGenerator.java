// IDGenerator.java
package edu.wtbu.util;

import java.util.Random;

public class IDGenerator {
    
    /**
     * 生成10位学号（年份开头）
     */
    public static String generateStudentId() {
        String year = String.valueOf(java.time.Year.now().getValue());
        Random random = new Random();
        // 生成6位随机数字，确保总长度10位
        String randomPart = String.format("%06d", random.nextInt(1000000));
        return year + randomPart;
    }
    
    /**
     * 生成5位活动ID
     */
    public static String generateActivityId() {
        Random random = new Random();
        return String.format("%05d", random.nextInt(100000));
    }
    
    /**
     * 生成5位报名ID
     */
    public static String generateSignupId() {
        Random random = new Random();
        return String.format("%05d", random.nextInt(100000));
    }
}