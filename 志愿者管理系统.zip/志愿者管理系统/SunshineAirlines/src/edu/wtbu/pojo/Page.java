package edu.wtbu.pojo;

/**
 * 分页参数封装类实体类（Plain Old Java Objects，POJO），用于封装业务数据，如用户信息、知识信息等相关类
 * 用于封装与分页查询相关的参数信息
 */
public class Page {
    /**
     * 总记录数（符合查询条件的总数据量）
     */
    int total;
    
    /**
     * 当前页码（从1开始计数）
     */
    int startPage;
    
    /**
     * 每页显示条目数
     */
    int pageSize;

    /**
     * 无参构造函数（用于反射创建对象）
     */
    public Page() {
        // 初始化时不设置任何参数值
    }

    /**
     * 全参数构造函数
     * @param total 总记录数
     * @param startPage 当前页码（从1开始）
     * @param pageSize 每页显示条目数
     */
    public Page(int total, int startPage, int pageSize) {
        this.total = total;
        this.startPage = startPage;
        this.pageSize = pageSize;
    }

    // 以下为属性的getter和setter方法
    
    /**
     * 获取总记录数
     * @return 符合查询条件的总数据量
     */
    public int getTotal() {
        return total;
    }

    /**
     * 设置总记录数
     * @param total 要设置的总记录数
     */
    public void setTotal(int total) {
        this.total = total;
    }

    /**
     * 获取当前页码
     * @return 当前页码（从1开始计数）
     */
    public int getStartPage() {
        return startPage;
    }

    /**
     * 设置当前页码
     * @param startPage 要设置的当前页码（建议从1开始）
     */
    public void setStartPage(int startPage) {
        this.startPage = startPage;
    }

    /**
     * 获取每页显示条目数
     * @return 每页显示的数据条数
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * 设置每页显示条目数
     * @param pageSize 要设置的每页数据量（需大于0）
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}