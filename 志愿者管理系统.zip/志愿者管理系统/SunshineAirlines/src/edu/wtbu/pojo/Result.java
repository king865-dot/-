package edu.wtbu.pojo;

/**
 * 通用响应结果封装类
 * 用于统一接口返回格式，包含状态标识、分页信息和业务数据
 */
public class Result {
    /**
     * 状态标识（通常用于表示操作结果）
     * 示例值："success"表示成功，"fail"表示失败，"error"表示系统错误
     */
    String flag;
    
    /**
     * 分页信息对象（当接口需要分页时使用）
     * 包含总记录数、当前页码等分页参数
     */
    Page page;
    
    /**
     * 业务数据载体（可存储任意类型返回数据）
     * 建议使用具体类型转换后再进行操作
     */
    Object data;

    /**
     * 无参构造函数（用于序列化/反序列化）
     */
    public Result() {
        // 空构造方法用于框架创建对象
    }

    /**
     * 全参数构造函数
     * @param flag 状态标识
     * @param page 分页信息对象（可为null）
     * @param data 业务数据对象（可为null）
     */
    public Result(String flag, Page page, Object data) {
        this.flag = flag;
        this.page = page;
        this.data = data;
    }

    // 以下是属性的访问器方法

    /**
     * 获取状态标识
     * @return 当前结果的状态标识字符串
     */
    public String getFlag() {
        return flag;
    }

    /**
     * 设置状态标识
     * @param flag 建议使用预定义的常量值（如："success", "fail"）
     */
    public void setFlag(String flag) {
        this.flag = flag;
    }

    /**
     * 获取分页信息对象
     * @return Page分页对象，可能为null（当接口不需要分页时）
     */
    public Page getPage() {
        return page;
    }

    /**
     * 设置分页信息对象
     * @param page 分页参数封装对象
     */
    public void setPage(Page page) {
        this.page = page;
    }

    /**
     * 获取业务数据对象
     * @return Object类型数据，使用时需要做类型转换
     */
    public Object getData() {
        return data;
    }

    /**
     * 设置业务数据对象
     * @param data 可以是任意Java对象（建议使用JSON友好类型）
     */
    public void setData(Object data) {
        this.data = data;
    }
}