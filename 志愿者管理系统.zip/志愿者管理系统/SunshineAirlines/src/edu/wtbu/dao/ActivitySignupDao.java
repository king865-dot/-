// ActivitySignupDao.java
package edu.wtbu.dao;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.helper.MySqlHelper;
import edu.wtbu.util.IDGenerator;

public class ActivitySignupDao {
    
    // 学生报名活动
    public static int signupActivity(String activityId, String studentId) {
        // 检查是否已报名
        String checkSql = "SELECT COUNT(1) AS cnt FROM activity_signup WHERE activity_id=? AND student_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(checkSql, 
                new Object[] { activityId, studentId });
        if (list != null && !list.isEmpty() && Integer.parseInt(list.get(0).get("cnt").toString()) > 0) {
            return -1; // 已报名
        }
        
        // 检查活动是否存在且状态为published
        String activityCheckSql = "SELECT COUNT(1) AS cnt FROM activity WHERE activity_id=? AND status='published'";
        List<HashMap<String, Object>> activityList = MySqlHelper.executeQueryReturnMap(activityCheckSql, 
                new Object[] { activityId });
        if (activityList == null || activityList.isEmpty() || 
            Integer.parseInt(activityList.get(0).get("cnt").toString()) == 0) {
            return -2; // 活动不存在或未发布
        }
        
        String signupId = IDGenerator.generateSignupId();
        String sql = "INSERT INTO activity_signup (signup_id, activity_id, student_id, signup_time) " +
                    "VALUES(?,?,?,NOW())";
        return MySqlHelper.executeUpdate(sql, new Object[] { signupId, activityId, studentId });
    }
    
    // 查询活动报名列表
    public static List<HashMap<String, Object>> findSignupListByActivity(String activityId, String status, int startPage, int pageSize) {
        String sql = "SELECT s.*, st.name, st.phone, c.class_name FROM activity_signup s " +
                    "JOIN student st ON s.student_id = st.student_id " +
                    "JOIN class c ON st.class_id = c.class_id " +
                    "WHERE s.activity_id=? AND (? = '' OR s.status = ?) " +
                    "ORDER BY s.signup_time DESC LIMIT ?,?";
        return MySqlHelper.executeQueryReturnMap(sql, 
                new Object[] { activityId, status, status, (startPage-1) * pageSize, pageSize });
    }
    
    // 获取活动报名总数
    public static int findSignupCountByActivity(String activityId, String status) {
        String sql = "SELECT COUNT(1) AS Total FROM activity_signup WHERE activity_id=? AND (? = '' OR status = ?)";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql,
                new Object[] { activityId, status, status });
        return (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).get("Total").toString()) : 0;
    }
    
    // 更新报名状态 - 手动设置更新时间
    public static int updateSignupStatus(String signupId, String status) {
        String sql = "UPDATE activity_signup SET status=?, update_time=NOW() WHERE signup_id=?";
        return MySqlHelper.executeUpdate(sql, new Object[] { status, signupId });
    }
    
    // 查询学生报名记录
    public static List<HashMap<String, Object>> findStudentSignups(String studentId, int startPage, int pageSize) {
        String sql = "SELECT s.*, a.title, a.start_time, a.location, a.organizer FROM activity_signup s " +
                    "JOIN activity a ON s.activity_id = a.activity_id " +
                    "WHERE s.student_id=? ORDER BY s.signup_time DESC LIMIT ?,?";
        return MySqlHelper.executeQueryReturnMap(sql, 
                new Object[] { studentId, (startPage-1) * pageSize, pageSize });
    }
    
    // 获取学生报名总数
    public static int findStudentSignupCount(String studentId) {
        String sql = "SELECT COUNT(1) AS Total FROM activity_signup WHERE student_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { studentId });
        return (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).get("Total").toString()) : 0;
    }
    
    // 根据报名ID获取报名详情
    public static HashMap<String, Object> findSignupById(String signupId) {
        String sql = "SELECT s.*, a.title, a.default_hours FROM activity_signup s " +
                    "JOIN activity a ON s.activity_id = a.activity_id " +
                    "WHERE s.signup_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { signupId });
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
}