// ServiceHoursDao.java
package edu.wtbu.dao;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.helper.MySqlHelper;

public class ServiceHoursDao {
    
    // 记录服务时长
    public static int recordServiceHours(String studentId, String activityId, float hours) {
        // 检查是否已记录
        String checkSql = "SELECT COUNT(1) AS cnt FROM service_hours WHERE student_id=? AND activity_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(checkSql, 
                new Object[] { studentId, activityId });
        if (list != null && !list.isEmpty() && Integer.parseInt(list.get(0).get("cnt").toString()) > 0) {
            return -1; // 已记录
        }
        
        String sql = "INSERT INTO service_hours (student_id, activity_id, hours, earn_date) " +
                    "VALUES(?,?,?,CURDATE())";
        int result = MySqlHelper.executeUpdate(sql, new Object[] { studentId, activityId, hours });
        
        // 更新学生总服务时长
        if (result > 0) {
            updateStudentTotalHours(studentId);
        }
        
        return result;
    }
    
    // 更新学生总服务时长
    public static int updateStudentTotalHours(String studentId) {
        String sql = "UPDATE student SET total_service_hours = " +
                    "(SELECT COALESCE(SUM(hours), 0) FROM service_hours WHERE student_id=?) " +
                    "WHERE student_id=?";
        return MySqlHelper.executeUpdate(sql, new Object[] { studentId, studentId });
    }
    
    // 查询个人服务档案
    public static List<HashMap<String, Object>> findStudentServiceRecord(String studentId) {
        String sql = "SELECT sh.*, a.title, a.organizer, a.start_time FROM service_hours sh " +
                    "JOIN activity a ON sh.activity_id = a.activity_id " +
                    "WHERE sh.student_id=? ORDER BY sh.earn_date DESC";
        return MySqlHelper.executeQueryReturnMap(sql, new Object[] { studentId });
    }
    
    // 统计个人总服务时长
    public static float getStudentTotalHours(String studentId) {
        String sql = "SELECT COALESCE(SUM(hours), 0) AS total_hours FROM service_hours WHERE student_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { studentId });
        if (list != null && !list.isEmpty()) {
            return Float.parseFloat(list.get(0).get("total_hours").toString());
        }
        return 0;
    }
    
    // 按班级统计服务时长
    public static List<HashMap<String, Object>> getClassHoursStats() {
        String sql = "SELECT c.class_id, c.class_name, c.college, " +
                    "COALESCE(SUM(sh.hours), 0) as total_hours, " +
                    "COUNT(DISTINCT sh.student_id) as student_count " +
                    "FROM class c " +
                    "LEFT JOIN student s ON c.class_id = s.class_id " +
                    "LEFT JOIN service_hours sh ON s.student_id = sh.student_id " +
                    "GROUP BY c.class_id, c.class_name, c.college " +
                    "ORDER BY total_hours DESC";
        return MySqlHelper.executeQueryReturnMap(sql, null);
    }
    
    // 按学院统计服务时长
    public static List<HashMap<String, Object>> getCollegeHoursStats() {
        String sql = "SELECT c.college, " +
                    "COALESCE(SUM(sh.hours), 0) as total_hours, " +
                    "COUNT(DISTINCT sh.student_id) as student_count, " +
                    "COUNT(DISTINCT sh.activity_id) as activity_count " +
                    "FROM class c " +
                    "LEFT JOIN student s ON c.class_id = s.class_id " +
                    "LEFT JOIN service_hours sh ON s.student_id = sh.student_id " +
                    "GROUP BY c.college " +
                    "ORDER BY total_hours DESC";
        return MySqlHelper.executeQueryReturnMap(sql, null);
    }
}