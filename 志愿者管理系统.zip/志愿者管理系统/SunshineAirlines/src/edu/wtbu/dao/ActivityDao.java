// ActivityDao.java
package edu.wtbu.dao;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.helper.MySqlHelper;
import edu.wtbu.util.IDGenerator;

public class ActivityDao {
    
    // 分页查询活动列表
	public static List<HashMap<String, Object>> findActivityListByPage(String title, String status, int startPage, int pageSize) {
	    // 字符编码调试
	    System.out.println("=== 字符编码调试 ===");
	    System.out.println("接收到的title原始值: " + title);
	    
	    // 如果title是乱码，尝试修复
	    if (title != null && title.contains("?")) {
	        System.out.println("检测到乱码，尝试修复...");
	        // 这里可以添加字符编码修复逻辑
	    }
	    
	    String sql = "SELECT * FROM activity WHERE title LIKE ? AND (? = '' OR status = ?) " + 
	                "ORDER BY create_time DESC LIMIT ?,?";
	    
	    System.out.println("SQL参数 - title: '" + title + "', status: '" + status + "'");
	    
	    List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql,
	            new Object[] { "%" + title + "%", status, status, (startPage-1) * pageSize, pageSize });
	    
	    System.out.println("查询结果数量: " + (list != null ? list.size() : 0));
        
        // 数据验证和清理
        if (list != null) {
            for (HashMap<String, Object> activity : list) {
                // 确保必要字段不为空
                if (activity.get("title") == null) {
                    activity.put("title", "未命名活动");
                }
                if (activity.get("organizer") == null) {
                    activity.put("organizer", "未知主办方");
                }
                if (activity.get("location") == null) {
                    activity.put("location", "待定地点");
                }
                System.out.println("活动数据: " + activity);
            }
        } else {
            System.out.println("查询结果为空");
        }
        
        return list;
    }
    
    // 获取活动总数
    public static int findActivityCount(String title, String status) {
        String sql = "SELECT COUNT(1) AS Total FROM activity WHERE title LIKE ? AND (? = '' OR status = ?)";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql,
                new Object[] { "%" + title + "%", status, status });
        return (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).get("Total").toString()) : 0;
    }
    
    // 获取所有已发布的活动（学生用）
    public static List<HashMap<String, Object>> findPublishedActivities(int startPage, int pageSize) {
        String sql = "SELECT * FROM activity WHERE status='published' ORDER BY start_time DESC LIMIT ?,?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, 
                new Object[] { (startPage-1) * pageSize, pageSize });
        
        // 数据验证和清理
        if (list != null) {
            for (HashMap<String, Object> activity : list) {
                if (activity.get("title") == null) {
                    activity.put("title", "未命名活动");
                }
            }
        }
        
        return list;
    }
    
    // 获取已发布活动总数
    public static int findPublishedActivityCount() {
        String sql = "SELECT COUNT(1) AS Total FROM activity WHERE status='published'";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, null);
        return (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).get("Total").toString()) : 0;
    }
    
    // 添加活动
    public static int addActivity(HashMap<String, Object> map) {
        String activityId = IDGenerator.generateActivityId();
        String sql = "INSERT INTO activity (activity_id, title, description, organizer, start_time, " +
                    "end_time, location, recruit_count, default_hours, status) VALUES(?,?,?,?,?,?,?,?,?,?)";
        
        // 数据验证
        if (map.get("title") == null || map.get("title").toString().trim().isEmpty()) {
            return -1; // 标题不能为空
        }
        
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    activityId,
                    map.get("title"),
                    map.get("description") != null ? map.get("description") : "",
                    map.get("organizer") != null ? map.get("organizer") : "",
                    map.get("startTime"),
                    map.get("endTime"),
                    map.get("location") != null ? map.get("location") : "",
                    map.get("recruitCount"),
                    map.get("defaultHours") != null ? map.get("defaultHours") : 0.0f,
                    map.get("status") != null ? map.get("status") : "draft"
                });
    }
    
    // 更新活动信息 - 手动设置更新时间
    public static int updateActivity(HashMap<String, Object> map) {
        String sql = "UPDATE activity SET title=?, description=?, organizer=?, start_time=?, " +
                    "end_time=?, location=?, recruit_count=?, default_hours=?, status=?, update_time=NOW() WHERE activity_id=?";
        
        // 数据验证
        if (map.get("title") == null || map.get("title").toString().trim().isEmpty()) {
            return -1; // 标题不能为空
        }
        
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    map.get("title"),
                    map.get("description") != null ? map.get("description") : "",
                    map.get("organizer") != null ? map.get("organizer") : "",
                    map.get("startTime"),
                    map.get("endTime"),
                    map.get("location") != null ? map.get("location") : "",
                    map.get("recruitCount"),
                    map.get("defaultHours") != null ? map.get("defaultHours") : 0.0f,
                    map.get("status") != null ? map.get("status") : "draft",
                    map.get("activityId")
                });
    }
    
    // 根据ID查询活动详情
    public static HashMap<String, Object> findByActivityId(String activityId) {
        String sql = "SELECT * FROM activity WHERE activity_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { activityId });
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
    
    // 更新活动状态 - 手动设置更新时间
    public static int updateActivityStatus(String activityId, String status) {
        String sql = "UPDATE activity SET status=?, update_time=NOW() WHERE activity_id=?";
        return MySqlHelper.executeUpdate(sql, new Object[] { status, activityId });
    }
}