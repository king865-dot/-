// StudentDao.java
package edu.wtbu.dao;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.helper.MySqlHelper;

public class StudentDao {
    
    // 学生登录验证
    public static HashMap<String, Object> login(String studentId, String password) {
        System.out.println("尝试登录 - 学号: " + studentId + ", 密码: " + password);
        
        String sql = "SELECT s.*, c.class_name, c.college FROM student s " + 
                    "JOIN class c ON s.class_id = c.class_id " + 
                    "WHERE s.student_id=? AND s.password=?";
        
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, 
                new Object[] { studentId, password });
        
        System.out.println("查询结果数量: " + (list != null ? list.size() : 0));
        
        if (list != null && !list.isEmpty()) {
            System.out.println("找到用户: " + list.get(0).get("name"));
            return list.get(0);
        } else {
            System.out.println("未找到匹配的用户");
            return null;
        }
    }
    
    // 分页查询学生列表
    public static List<HashMap<String, Object>> findStudentListByPage(String keyword, int startPage, int pageSize) {
        String sql = "SELECT s.*, c.class_name, c.college FROM student s " +
                    "JOIN class c ON s.class_id = c.class_id " +
                    "WHERE s.student_id LIKE ? OR s.name LIKE ? OR c.class_name LIKE ? " +
                    "ORDER BY s.student_id ASC LIMIT ?,?";
        return MySqlHelper.executeQueryReturnMap(sql, 
                new Object[] { 
                    "%" + keyword + "%", 
                    "%" + keyword + "%",
                    "%" + keyword + "%",
                    (startPage-1) * pageSize, 
                    pageSize 
                });
    }
    
    // 获取学生总数
    public static int findStudentCount(String keyword) {
        String sql = "SELECT COUNT(1) AS Total FROM student s " +
                    "JOIN class c ON s.class_id = c.class_id " +
                    "WHERE s.student_id LIKE ? OR s.name LIKE ? OR c.class_name LIKE ?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql,
                new Object[] { "%" + keyword + "%", "%" + keyword + "%", "%" + keyword + "%" });
        return (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).get("Total").toString()) : 0;
    }
    
    // 添加学生
    public static int addStudent(HashMap<String, Object> map) {
        String sql = "INSERT INTO student (student_id, name, password, role, class_id, phone, email) " +
                    "VALUES(?,?,?,?,?,?,?)";
        
        // 详细的调试信息
        System.out.println("=== DAO层添加学生 ===");
        System.out.println("SQL: " + sql);
        System.out.println("参数详情:");
        System.out.println("  studentId: " + map.get("studentId"));
        System.out.println("  name: " + map.get("name"));
        System.out.println("  password: " + map.get("password"));
        System.out.println("  role: " + map.get("role"));
        System.out.println("  classId: " + map.get("classId"));
        System.out.println("  phone: " + map.get("phone"));
        System.out.println("  email: " + map.get("email"));
        
        Object[] params = new Object[] { 
            map.get("studentId"),
            map.get("name"),
            map.get("password"),
            map.get("role"),
            map.get("classId"),
            map.get("phone"),
            map.get("email")
        };
        
        try {
            int result = MySqlHelper.executeUpdate(sql, params);
            System.out.println("数据库操作结果: " + result);
            return result;
        } catch (Exception e) {
            System.err.println("数据库操作异常: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }
    
    // 更新学生信息 - 手动设置更新时间
    public static int updateStudent(HashMap<String, Object> map) {
        String sql = "UPDATE student SET name=?, role=?, class_id=?, phone=?, email=?, update_time=NOW() " +
                    "WHERE student_id=?";
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    map.get("name"),
                    map.get("role"),
                    map.get("classId"),
                    map.get("phone"),
                    map.get("email"),
                    map.get("studentId")
                });
    }
    
    // 删除学生
    public static int deleteStudent(String studentId) {
        String sql = "DELETE FROM student WHERE student_id=?";
        return MySqlHelper.executeUpdate(sql, new Object[] { studentId });
    }
    
    // 根据学号查询学生详情
    public static HashMap<String, Object> findByStudentId(String studentId) {
        String sql = "SELECT s.*, c.class_name, c.college FROM student s " +
                    "JOIN class c ON s.class_id = c.class_id " +
                    "WHERE s.student_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { studentId });
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
    
    // 检查学号是否已存在
    public static boolean isStudentIdExists(String studentId) {
        String sql = "SELECT COUNT(1) AS cnt FROM student WHERE student_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { studentId });
        return list != null && !list.isEmpty() && Integer.parseInt(list.get(0).get("cnt").toString()) > 0;
    }
    
    // 获取所有班级列表
    public static List<HashMap<String, Object>> findAllClasses() {
        String sql = "SELECT * FROM class ORDER BY class_name ASC";
        return MySqlHelper.executeQueryReturnMap(sql, null);
    }
}