/*
Navicat MySQL Data Transfer

Source Server         : Session1
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : session1

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2025-10-30 13:30:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `activity`
-- ----------------------------
DROP TABLE IF EXISTS `activity`;
CREATE TABLE `activity` (
  `activity_id` varchar(5) NOT NULL COMMENT '活动ID',
  `title` varchar(100) NOT NULL COMMENT '活动标题',
  `description` text COMMENT '活动描述',
  `organizer` varchar(100) NOT NULL COMMENT '主办方',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime NOT NULL COMMENT '结束时间',
  `location` varchar(200) NOT NULL COMMENT '活动地点',
  `recruit_count` int(10) unsigned NOT NULL COMMENT '招募人数',
  `current_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当前报名人数',
  `default_hours` float NOT NULL DEFAULT '0' COMMENT '默认服务时长',
  `status` enum('draft','published','finished','cancelled') NOT NULL DEFAULT 'draft' COMMENT '活动状态',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`activity_id`),
  KEY `idx_title` (`title`),
  KEY `idx_status` (`status`),
  KEY `idx_time` (`start_time`,`end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动信息表';

-- ----------------------------
-- Records of activity
-- ----------------------------
INSERT INTO `activity` VALUES ('10001', '校园清洁日', '维护校园环境，清理垃圾', '学生会', '2024-06-01 01:00:00', '2024-06-01 04:00:00', '校园广场', '20', '0', '3', 'finished', '2025-10-29 16:45:14', '2025-10-30 11:00:51');
INSERT INTO `activity` VALUES ('10002', '图书馆志愿服务', '协助图书馆整理书籍', '图书馆', '2024-06-05 14:00:00', '2024-06-05 17:00:00', '图书馆', '15', '0', '3', 'published', '2025-10-29 16:45:14', null);
INSERT INTO `activity` VALUES ('10003', '敬老院慰问', '看望老人，表演节目', '青年志愿者协会', '2024-06-10 08:00:00', '2024-06-10 16:00:00', '阳光敬老院', '25', '0', '8', 'published', '2025-10-29 16:45:14', null);

-- ----------------------------
-- Table structure for `activity_signup`
-- ----------------------------
DROP TABLE IF EXISTS `activity_signup`;
CREATE TABLE `activity_signup` (
  `signup_id` varchar(5) NOT NULL COMMENT '报名ID',
  `activity_id` varchar(5) NOT NULL COMMENT '活动ID',
  `student_id` varchar(10) NOT NULL COMMENT '学生ID',
  `signup_time` datetime NOT NULL COMMENT '报名时间',
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending' COMMENT '报名状态',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`signup_id`),
  UNIQUE KEY `uk_activity_student` (`activity_id`,`student_id`),
  KEY `idx_activity_id` (`activity_id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `activity_signup_ibfk_1` FOREIGN KEY (`activity_id`) REFERENCES `activity` (`activity_id`),
  CONSTRAINT `activity_signup_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动报名表';

-- ----------------------------
-- Records of activity_signup
-- ----------------------------
INSERT INTO `activity_signup` VALUES ('S001', '10003', '2025081560', '2025-10-30 11:36:27', 'pending', '2025-10-30 11:36:41', '2025-11-01 11:36:44');

-- ----------------------------
-- Table structure for `class`
-- ----------------------------
DROP TABLE IF EXISTS `class`;
CREATE TABLE `class` (
  `class_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '班级ID',
  `class_name` varchar(50) NOT NULL COMMENT '班级名称',
  `college` varchar(50) NOT NULL COMMENT '所属学院',
  `department` varchar(50) NOT NULL COMMENT '所属系部',
  `student_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '班级人数',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='班级信息表';

-- ----------------------------
-- Records of class
-- ----------------------------
INSERT INTO `class` VALUES ('1', '计算机科学与技术1班', '信息工程学院', '计算机系', '45', '2025-10-29 16:45:14');
INSERT INTO `class` VALUES ('2', '软件工程2班', '信息工程学院', '软件工程系', '42', '2025-10-29 16:45:14');
INSERT INTO `class` VALUES ('3', '电子信息工程1班', '电子工程学院', '电子信息系', '38', '2025-10-29 16:45:14');

-- ----------------------------
-- Table structure for `service_hours`
-- ----------------------------
DROP TABLE IF EXISTS `service_hours`;
CREATE TABLE `service_hours` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `student_id` varchar(10) NOT NULL COMMENT '学生ID',
  `activity_id` varchar(5) NOT NULL COMMENT '活动ID',
  `hours` float NOT NULL COMMENT '获得时长',
  `earn_date` date NOT NULL COMMENT '获得日期',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_student_activity` (`student_id`,`activity_id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_activity_id` (`activity_id`),
  KEY `idx_earn_date` (`earn_date`),
  CONSTRAINT `service_hours_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`),
  CONSTRAINT `service_hours_ibfk_2` FOREIGN KEY (`activity_id`) REFERENCES `activity` (`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='服务时长表';

-- ----------------------------
-- Records of service_hours
-- ----------------------------
INSERT INTO `service_hours` VALUES ('1', '2025081560', '10001', '3', '2025-10-30', '2025-10-30 11:27:53');

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `student_id` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL COMMENT '姓名',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `role` enum('admin','student') NOT NULL DEFAULT 'student' COMMENT '角色',
  `class_id` int(10) unsigned NOT NULL COMMENT '班级ID',
  `phone` varchar(20) DEFAULT NULL COMMENT '联系方式',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `total_service_hours` float NOT NULL DEFAULT '0' COMMENT '总服务时长',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`student_id`),
  KEY `idx_class_id` (`class_id`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学生信息表';

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('2002092301', '张山', '123456', 'admin', '1', '13042721328', '1912342682@qq.com', '0', '2025-10-29 22:44:48', null);
INSERT INTO `student` VALUES ('2025081560', '李四', '123456', 'student', '2', '13042721328', '1912342682@qq.com', '0', '2025-10-29 22:42:53', null);
INSERT INTO `student` VALUES ('2025592900', '朱颖', '123456', 'student', '1', '13042721328', '1912342682@qq.com', '0', '2025-10-30 11:39:58', null);

-- ----------------------------
-- View structure for `v_service_statistics`
-- ----------------------------
DROP VIEW IF EXISTS `v_service_statistics`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_service_statistics` AS select `s`.`student_id` AS `student_id`,`s`.`name` AS `student_name`,`s`.`class_id` AS `class_id`,`c`.`class_name` AS `class_name`,`c`.`college` AS `college`,`c`.`department` AS `department`,count(`sh`.`id`) AS `activity_count`,coalesce(sum(`sh`.`hours`),0) AS `total_hours` from ((`student` `s` left join `service_hours` `sh` on((`s`.`student_id` = `sh`.`student_id`))) left join `class` `c` on((`s`.`class_id` = `c`.`class_id`))) group by `s`.`student_id`,`s`.`name`,`s`.`class_id`,`c`.`class_name`,`c`.`college`,`c`.`department` ;
